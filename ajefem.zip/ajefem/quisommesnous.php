<!doctype html>
<html class="no-js" lang="zxx">
    
   <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Actions de Jeunes et Femmes pour Entraide Mutuelle </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="manifest" href="site.webmanifest">
		<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">

		<!-- CSS here -->
            <link rel="stylesheet" href="assets/css/bootstrap.min.css">
            <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
            <link rel="stylesheet" href="assets/css/ticker-style.css">
            <link rel="stylesheet" href="assets/css/flaticon.css">
            <link rel="stylesheet" href="assets/css/slicknav.css">
            <link rel="stylesheet" href="assets/css/animate.min.css">
            <link rel="stylesheet" href="assets/css/magnific-popup.css">
            <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
            <link rel="stylesheet" href="assets/css/themify-icons.css">
            <link rel="stylesheet" href="assets/css/slick.css">
            <link rel="stylesheet" href="assets/css/nice-select.css">
            <link rel="stylesheet" href="assets/css/style.css">
   </head>

   <body>
       
    <!-- Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="assets/img/logo/logo.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader Start -->

    <header>
        <!-- Header Start -->
       <div class="header-area">
            <div class="main-header ">
                <div class="header-top black-bg d-none d-md-block">
                   <div class="container">
                       <div class="col-xl-12">
                            <div class="row d-flex justify-content-between align-items-center">
                                <div class="header-info-left">
                                    <ul>     
                                        <li><img src="assets/img/icon/header_icon1.png">Av. Cercle hypique / Nyalukemba / Ndendere / Bukavu - ville / Sud - Kivu / RD Congo </li>
                                        <li><img src="assets/img/icon/header_icon1.png" alt=""> 08 Octobre, 2020</li>
                                    </ul>
                                </div>
                                <div class="header-info-right">
                                    <ul class="header-social">   
									<a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="https://instagram.com/ajem830?igshid=YmMyMTA2M2Y="target="_blank"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-linkedin"></i></a>
                                   
                                    <a href="https://www.facebook.com/profile.php?id=100089649707488"target="_blank"><i class="fab fa-facebook"></i></a>
                                    <a href="https://www.facebook.com/profile.php?id=100089649707488"target="_blank"><i class="fab fa-youtube"></i></a>
                                       
                                    </ul>
                                </div>
                            </div>
                       </div>
                   </div>
                </div>
                <div class="header-mid d-none d-md-block">
                   <div class="container">
                        <div class="row d-flex align-items-center">
                            <!-- Logo -->
                            <div class="col-xl-3 col-lg-3 col-md-3">
                                <div class="logo">
                                    <a href="index.php"><img src="assets/img/logo/logo.png" alt=""></a>
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-9 col-md-9">
                                <div class="header-banner f-right ">
                                    <img src="assets/img/hero/header_card.jpg" alt="">
                                </div>
                            </div>
                        </div>
                   </div>
                </div>
               <div class="header-bottom header-sticky">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-xl-10 col-lg-10 col-md-12 header-flex">
                                <!-- sticky -->
                                    <div class="sticky-logo">
                                        <a href="index.html"><img src="assets/img/logo/logo.png" alt=""></a>
                                    </div>
                                <!-- Main-menu -->
                                <div class="main-menu d-none d-md-block">
                                    <nav>                  
                                        <ul id="navigation">    
                                            <li><a href="index.php">Accueil</a></li>
                                            <li><a href="quisommesnous.php">Qui sommes-nous ?</a></li>
                                            <li><a href="about.html">About</a></li>
                                            <li><a href="latest_news.html">Latest News</a></li>
                                            
                                            <li><a href="#">Domaines d'intervention</a>
                                                <ul class="submenu">
                                                    <li><a href="elements.html">Informatique</a></li>
                                                    <li><a href="blog.html">Education et Protection</a></li>
                                                    <li><a href="single-blog.html">Entrepreneuriat et formation professionnelle</a></li>
                                                    <li><a href="details.html">Protection environnementale</a></li>
                                                    <li><a href="details.html">Santé et Wash/EHA</a></li>
                                                    <li><a href="details.html">Bonne gouvernance</a></li>
                                                    <li><a href="details.html">Agriculture </a></li>
                                                    <li><a href="details.html">Droits Humains</a></li>
                                                    <li><a href="details.html">Elevage</a></li>
                                                    <li><a href="details.html">Sports et Loisirs</a></li>
                                                </ul>
                                            </li>
											<li><a href="contact.php">Contact</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>             
                            <div class="col-xl-2 col-lg-2 col-md-4">
                                <div class="header-right-btn f-right d-none d-lg-block">
                                    <i class="fas fa-search special-tag"></i>
                                    <div class="search-box">
                                        <form action="#">
                                            <input type="text" placeholder="Search">
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Mobile Menu -->
                            <div class="col-12">
                                <div class="mobile_menu d-block d-md-none"></div>
                            </div>
                        </div>
                    </div>
               </div>
            </div>
       </div>
        <!-- Header End -->
    </header>

    
    <main>
        <!-- About US Start -->
        <div class="about-area">
            <div class="container">
                    <!-- Hot Aimated News Tittle-->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="trending-tittle">
                                <strong>Trending now</strong>
                                <!-- <p>Rem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                                <div class="trending-animated">
                                    <ul id="js-news" class="js-hidden">
                                        <li class="news-item">Bangladesh dolor sit amet, consectetur adipisicing elit.</li>
                                        <li class="news-item">Spondon IT sit amet, consectetur.......</li>
                                        <li class="news-item">Rem ipsum dolor sit amet, consectetur adipisicing elit.</li>
                                    </ul>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                   <div class="row">
                        <div class="col-lg-12">
                            <!-- Trending Tittle -->
                                    <div class="about-right mb-90">
                                        
                                        <div class="section-tittle mb-30 pt-30">
                                            <h3>PRESENTATION DE L'AJEFEM </h3>
											<br>
                                            <h3>O. Introduction </h3>
                                        </div>
										
                                        <div class="about-prea">
                                            
                                            <p class="about-pera1 mb-25">
											Toute initiative tendant vers une évolution doit être au profit des communautés vulnérables ; et que les organisations non gouvernementales doivent apporter une contribution tant soit peu au développement des populations au niveau local. 
											Soucieux d’apporter efficacement un appui holistique à titre des réponses urgentes et à long terme aux multiples besoins de personnes vulnérables pour la promotion des droits humains, la restauration et préservation de la paix, la lutte contre la pauvreté, l’autonomisation des femmes et hommes vulnérables et particulièrement la jeunesse désœuvrée ; pour un développement intégral à impact durable.
											La recherche de la paix (stabilisation de la RDC) et le progrès étant des sujets de grande préoccupation en République Démocratique du Congo et autant à l’échelle internationale, considérant par conséquent qu’il est utile de prendre des mesures pour les privilégier, déplorant non seulement la perdition de millier de jeunes mais aussi la violation des droits humains en générale.
											Les initiatives d’autoréglementation volontaire à l’article 37 de la constitution de la RD Congo du 18 juillet 2006 qui garantit la liberté d’association, d’où les pouvoirs publics collaborent avec les associations de la société civile contribuent au développement social, économique, intellectuel, moral et spirituel des populations et à l’éducation des citoyennes et des citoyens.
											Conscient de l’immense potentialité en ressources naturelles que regorge la République Démocratique du Congo, laquelle la classe en ordre utile sur le plan international ; sur ce qui repose l’espoir d’une part de sauvegarder l’environnement mondial et d’autre part devra constituer un instrument pour consolider la paix et le développement durable pour le bien être principalement des peuples Congolais mais aussi de l’ensemble de la région en Afrique face aux problèmes de sécurité sociale.
											Animés par la volonté d'unir nos efforts pour contribuer au développement durable qui s’appui à la protection de l’environnement et au bien-être social de notre région pour un nouvel élan et émergence de la population Congolaise en général et celle du Sud – Kivu en particulier.
											Réunis en Assemblée Générale, les membres effectifs ont créé une Association Sans But Lucratif dénommée  <b>« ACTIONS DE JEUNES ET FEMMES POUR L’ENTRAIDE MUTUELLE »</b> en sigle <b>« AJEFEM »</b> 
                                            </p>
											<div class="section-tittle mb-30 pt-30">
                                           
                                            
											<h3>2. Siège social  </h3>
											 <p class="about-pera1 mb-25">
											Le siège social est établi sur Av. Cercle Hypique, quartier Nyalukemba, Commune d’Ibanda, ville de Bukavu, province du Sud-Kivu, en République Démocratique du Congo.
 
                                            </p>
											<h3>3. Rayon d’action  </h3>
											 <p class="about-pera1 mb-25">
											Le rayon d’action s’étend sur toute l’étendue de la République Démocratique du Congo, à partir de la province du Sud-Kivu où se situe son siège social et pourra s’étendre sur d’autres provinces au fur et à mesure que les besoins se présentent et surtout la disponibilité de financement.
                                            </p>
											<h3>4. Durée  </h3>
											 <p class="about-pera1 mb-25">
											L’Asbl <b>« AJEFEM » </b> est créée pour une durée indéterminée.
                                            </p>
											<h3>5. Objectif global </h3>
											 <p class="about-pera1 mb-25">
											
											Promouvoir, encadrer et gérer les activités de femmes et de jeunes en faveur des classes défavorisées.

                                            </p>
											<h3>6. Objectifs spécifiques </h3>
											 <p class="about-pera1 mb-25">
												•	Organiser et faciliter des projets qui développent le potentiel des jeunes et femmes ; </br>
												•	Eveiller la conscience de la femme et de la jeunesse à un changement de mentalité par l’éducation citoyenne ;</br>
												•	Développer et promouvoir la coexistence pacifique à travers des activités humanitaires qui favorise la consolidation de la paix et la démocratisation par le biais de la société civile ;</br>
												•	Lutter contre l’insertion des jeunes dans les conflits, la pauvreté, le chômage et la délinquance juvénile ;</br>
												•	Défendre les intérêts et les droits de la femme et de la jeunesse ;</br>
												•	Lutter contre les violences basées sur le genre ;</br>
												•	Sensibiliser et mobiliser le monde féminin au processus de la pacification et de la réconciliation ;</br>
												•	Favoriser l’autonomie financière des femmes et des jeunes vulnérables par l’octroi de micro crédit afin de mettre en place des AGR communautaires, individuelles et les AVEC ;</br>
												•	Encourager efficacement le développement socio-professionnel, culturel et intellectuel des femmes et des jeunes, notamment par l’apprentissage des métiers, la création des centres de formation dynamiques et spécialisés, mise en place des coopératives de développement. </br>
												Ainsi l’objet social s’élargira au fur et à mesure que les besoins l’exigent.

                                            </p>
											<h3>7. Les Stratégies d’intervention  </h3>
											 <p class="about-pera1 mb-25">
											Les stratégies suivantes seront poursuivies en vue de la réalisation de son objet social :</br>
											•	Organiser les ateliers de formation et de renforcement des capacités en faveur des femmes et de la jeunesse ;</br>
											•	Créer des unités de production susceptibles de générer l’emploi et de procurer le revenu ;</br>
											•	Créer des centres de formation ;</br>
											•	Mener de campagne de sensibilisation de masse à travers les médias ;</br>
											•	Mettre en place les actions pilotes de développement.

                                            </p>
											<h3>8. Les groupes cibles  </h3>
											 <p class="about-pera1 mb-25">
											La jeunesse désœuvrée, les femmes et les hommes victimes d’actes de violences, les filles – mères et autres vulnérables,… 

                                            </p>
											<h3>9. Les Domaines d’intervention   </h3>
											 <p class="about-pera1 mb-25">
											L’asbl <b>« AJEFEM » </b> orientera ses activités dans les domaines suivants :</br>
											•	L'éducation citoyenne à la paix et à la bonne gouvernance ;</br>
											•	Entrepreneuriat et formation professionnelle ; </br>
											•	Agriculture ;</br>
											•	Sports et loisirs ;</br>
											•	Protection sociale ;</br>
											•	Gestion et Résolution des Conflits ;</br>
											•	Droits humains ;</br>
											•	Elevage ;</br>
											•	Santé et Wash / EHA ;</br>
											•	Environnement et habitat. 

                                            </p>
											<h3>10. Vision   </h3>
											 <p class="about-pera1 mb-25">
											La vision de l’asbl <b>« AJEFEM » </b> est de former un réseau des femmes et des jeunes cadres compétents capables d’impacter les communautés par des actions de développement endogène, autocentré, autogéré et durable. 

                                            </p>
											<h3>11. Mission   </h3>
											 <p class="about-pera1 mb-25">
											L’asbl <b>« AJEFEM » </b> cherche à soutenir et promouvoir les stratégies de développement intégré pour une auto-prise en charge durable créant d’opportunité visant le bien-être, le renforcement des capacités, le relèvement communautaire, la résilience et la promotion des femmes et des jeunes cadres développeurs.
                                            </p>
                                        </div>
                                        </div>
                                    </div>
                        </div>
                        
                   </div>
            </div>
        </div>
        <!-- About US End -->
    </main>
   <footer>
       <!-- Footer Start-->
       <div class="footer-area footer-padding fix">
            <div class="container">
                <div class="row d-flex justify-content-between">
                    <div class="col-xl-5 col-lg-5 col-md-7 col-sm-12">
                        <div class="single-footer-caption">
                            <div class="single-footer-caption">
                                <!-- logo -->
                                <div class="footer-logo">
                                    <a href="index.html"><img src="assets/img/logo/logo2_footer.png" alt=""></a>
                                </div>
                                <div class="footer-tittle">
                                    <div class="footer-pera">
                                        <p>Suscipit mauris pede for con sectetuer sodales adipisci for cursus fames lectus tempor da blandit gravida sodales  Suscipit mauris pede for con sectetuer sodales adipisci for cursus fames lectus tempor da blandit gravida sodales  Suscipit mauris pede for sectetuer.</p>
                                    </div>
                                </div>
                                <!-- social -->
                                <div class="footer-social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4  col-sm-6">
                        <div class="single-footer-caption mt-60">
                            <div class="footer-tittle">
                                <h4>Newsletter</h4>
                                <p>Heaven fruitful doesn't over les idays appear creeping</p>
                                <!-- Form -->
                                <div class="footer-form" >
                                    <div id="mc_embed_signup">
                                        <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
                                        method="get" class="subscribe_form relative mail_part">
                                            <input type="email" name="email" id="newsletter-form-email" placeholder="Email Address"
                                            class="placeholder hide-on-focus" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ' Email Address '">
                                            <div class="form-icon">
                                            <button type="submit" name="submit" id="newsletter-submit"
                                            class="email_icon newsletter-submit button-contactForm"><img src="assets/img/logo/form-iocn.png" alt=""></button>
                                            </div>
                                            <div class="mt-10 info"></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-5 col-sm-6">
                        <div class="single-footer-caption mb-50 mt-60">
                            <div class="footer-tittle">
                                <h4>Instagram Feed</h4>
                            </div>
                            <div class="instagram-gellay">
                                <ul class="insta-feed">
                                    <li><a href="#"><img src="assets/img/post/instra1.jpg" alt=""></a></li>
                                    <li><a href="#"><img src="assets/img/post/instra2.jpg" alt=""></a></li>
                                    <li><a href="#"><img src="assets/img/post/instra3.jpg" alt=""></a></li>
                                    <li><a href="#"><img src="assets/img/post/instra4.jpg" alt=""></a></li>
                                    <li><a href="#"><img src="assets/img/post/instra5.jpg" alt=""></a></li>
                                    <li><a href="#"><img src="assets/img/post/instra6.jpg" alt=""></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       <!-- footer-bottom aera -->
       <div class="footer-bottom-area">
           <div class="container">
               <div class="footer-border">
                    <div class="row d-flex align-items-center justify-content-between">
                        <div class="col-lg-6">
                            <div class="footer-copy-right">
                                <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="ti-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="footer-menu f-right">
                                <ul>                             
                                    <li><a href="#">Terms of use</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="#">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
               </div>
           </div>
       </div>
       <!-- Footer End-->
   </footer>
   
	<!-- JS here -->
	
		<!-- All JS Custom Plugins Link Here here -->
        <script src="./assets/js/vendor/modernizr-3.5.0.min.js"></script>
		<!-- Jquery, Popper, Bootstrap -->
		<script src="./assets/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="./assets/js/popper.min.js"></script>
        <script src="./assets/js/bootstrap.min.js"></script>
	    <!-- Jquery Mobile Menu -->
        <script src="./assets/js/jquery.slicknav.min.js"></script>

		<!-- Jquery Slick , Owl-Carousel Plugins -->
        <script src="./assets/js/owl.carousel.min.js"></script>
        <script src="./assets/js/slick.min.js"></script>
        <!-- Date Picker -->
        <script src="./assets/js/gijgo.min.js"></script>
		<!-- One Page, Animated-HeadLin -->
        <script src="./assets/js/wow.min.js"></script>
		<script src="./assets/js/animated.headline.js"></script>
        <script src="./assets/js/jquery.magnific-popup.js"></script>

        <!-- Breaking New Pluging -->
        <script src="./assets/js/jquery.ticker.js"></script>
        <script src="./assets/js/site.js"></script>

		<!-- Scrollup, nice-select, sticky -->
        <script src="./assets/js/jquery.scrollUp.min.js"></script>
        <script src="./assets/js/jquery.nice-select.min.js"></script>
		<script src="./assets/js/jquery.sticky.js"></script>
        
        <!-- contact js -->
        <script src="./assets/js/contact.js"></script>
        <script src="./assets/js/jquery.form.js"></script>
        <script src="./assets/js/jquery.validate.min.js"></script>
        <script src="./assets/js/mail-script.js"></script>
        <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
        
		<!-- Jquery Plugins, main Jquery -->	
        <script src="./assets/js/plugins.js"></script>
        <script src="./assets/js/main.js"></script>
    </body>
</html>